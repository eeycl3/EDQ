// Header files that work for strings!

void oled_puts_rom_1x(char *s);
void oled_puts_rom_2x(char *s);
