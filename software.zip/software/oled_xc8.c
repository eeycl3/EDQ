#pragma config IESO=OFF, FCMEN=OFF, FOSC=INTIO67, PWRT=OFF, BOREN=OFF, WDTEN=OFF
#pragma config WDTPS=32768, MCLRE=ON, LPT1OSC=OFF, PBADEN=OFF, CCP2MX=PORTC
#pragma config STVREN=OFF, LVP=OFF, XINST=OFF, DEBUG=OFF, CP0=OFF, CP1=OFF
#pragma config CP2=OFF, CP3=OFF, CPB=OFF, CPD=OFF, WRT0=OFF, WRT1=OFF
#pragma config WRT2=OFF, WRT3=OFF, WRTB=OFF, WRTC=OFF, WRTD=OFF, EBTR0=OFF
#pragma config EBTR1=OFF, EBTR2=OFF, EBTR3=OFF, EBTRB=OFF
// Various includes for the display driver - not that these are MODIFIED from the originals
#include <stdio.h>
#include <xc.h>
#include <htc.h>
#include "oleds.h"
#include "oled_interface.h"
#include "oled_jib.h" 
#include "oled_cmd.h"
#include "timers.h" 
#include "Interrupts.h" 
#include <p18f46K20.h>
int DAC1=0;
int on_angle;// firing angle
int count=0;// record Z pulses
int time=0;
int rotate_speed;// desired  speed
int speed=0;// actual speed
int menu;// modes of menu
char direction[]="LEFT ";
int off_angle;//firing angle
unsigned int flag;
int bool_direction;// bool for direction detection
unsigned int stop_flag;// change direction flag: cancel the reset TMR1 value
float current;// feed back current
float d_current;// desired current
void InitializeSystem(void);
void ADC_Init(void);// ADC init
unsigned char ADC_Convert(void);
void main(void)
{
	char buffer[20];// A buffer into which we place text for sending to the OLED (do not worry about the 'auto' it is used to match the definition of sprintf in <stdio.h?
	InitializeSystem();	// initialise interrupts, PORTs, functions, etc
	// initialise the display
	oled_init();
	oled_clear();
	oled_refresh();
	// initialise variables.
	flag=0;// set +/-
	bool_direction=0;
	menu=0;
	on_angle=10;
	off_angle=70;
	stop_flag=0;
	rotate_speed=2000;
	count=0;
	time=0;

	while (1)
{		
			while (menu==0)// main menu
			{	
			CCPR2L = (off_angle*25/18)+5;
			CCPR1L = (on_angle*25/18)+5;
			oled_clear();
            sprintf(buffer, "On_angle:%d\n",on_angle);
            oled_puts_1x (buffer);
			sprintf(buffer, "Off_angle:%d\n",off_angle);
            oled_puts_1x (buffer);
			sprintf(buffer, "Speed:%d r/min\n",speed);
			oled_puts_1x (buffer);
			sprintf(buffer, "Direction:%s\n",direction);
			oled_puts_1x (buffer);
			sprintf(buffer, "RB4:set on_angle\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:set off_angle\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB6 set speed\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB1 set direction");
			oled_puts_1x (buffer);
            oled_refresh();
			}//menu 0

			while (menu==1)// set on_angle
			{
			oled_clear();	
			sprintf(buffer, "off_angle:%d\n",off_angle);
			oled_puts_1x (buffer);
			sprintf(buffer, "On_angle:%d\n",on_angle);
			oled_puts_1x (buffer);
			sprintf(buffer, "RB2 to set +/- angle\n");
			oled_puts_1x (buffer);
			if  (flag==0)
			{
			sprintf(buffer, "RB4:on_angle +1\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:on_angle +10\n");
			oled_puts_1x (buffer);
			}
			else
			{
			sprintf(buffer, "RB4:on_angle -1\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:on_angle -10\n");
			oled_puts_1x (buffer);
			}
			sprintf(buffer, "RB7:back to menu");
			oled_puts_1x (buffer);
			oled_refresh();
			CCPR2L = (off_angle*25/18)+5; // set CCP2
			CCPR1L = (on_angle*25/18)+5;// set CCP1
			
			}//menu1

				while (menu==2)// set off_angle?
			{
			oled_clear();
            sprintf(buffer, "off_angle:%d\n",off_angle);
			oled_puts_1x (buffer);
			sprintf(buffer, "On_angle:%d\n",on_angle);
			oled_puts_1x (buffer);
			sprintf(buffer, "RB2 set +/- angle\n");
			oled_puts_1x (buffer);
			if  (flag==0)
			{
			sprintf(buffer, "RB4:off_angle +1\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:off_angle +10\n");
			oled_puts_1x (buffer);
			}
			if (flag==1)
			{
			sprintf(buffer, "RB4:off_angle -1\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:off_angle -10\n");
			oled_puts_1x (buffer);
			}
			sprintf(buffer, "RB7:back to menu");
			oled_puts_1x (buffer);
			oled_refresh();
			CCPR2L = (off_angle*25/18)+5;// set CCP2
			CCPR1L = (on_angle*25/18)+5;// set CCP1						
			}// menu2

			
			while (menu==3)// set speed
			{
			oled_clear();
			sprintf(buffer, "actual_speed:%d\n",speed);
            oled_puts_1x (buffer);
            sprintf(buffer, "Speed:%d\n",rotate_speed);
            oled_puts_1x (buffer);
			sprintf(buffer, "RB2 to set +/- speed\n");
			oled_puts_1x (buffer);
			if (flag==0)
			{
			sprintf(buffer, "Increase speed\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB4:speed +1\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:speed +10\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB6:speed +100");
			oled_puts_1x (buffer);
			}
			if (flag==1)
			{
			sprintf(buffer, "decrease speed\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB4:speed -1\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB5:speed -10\n");
			oled_puts_1x (buffer);
			sprintf(buffer, "RB6:speed -100");
			oled_puts_1x (buffer);
			}
			oled_refresh();
			// speed_function();
			}//menu3

			while (menu==4)// direction change menu
			{
			stop_flag=1;
			oled_clear();
			oled_puts_2x ("waiting for changing");
			oled_refresh();
			if (LATDbits.LATD4==1)// current direction detection
			{
			while((LATDbits.LATD4==1)&&(speed<200));// wait  direction changing
				if(LATDbits.LATD5==1)
				{
				menu=0;stop_flag=0;break;
				}
			}//end if

			if (LATDbits.LATD5==1)// current direction detection
			{
			while((LATDbits.LATD5==1)&&(speed<200));// wait  direction changing
				if(LATDbits.LATD4==1)
				{
				menu=0; stop_flag=0;break;// recover reset TMR1 in INT0 go to menu
				}
			}
			
			}//menu4

							
}//while 1


}//end main

//#pragma interrupt InterruptServiceHigh  // "interrupt" pragma also for high priority
void interrupt ServiceHigh(void)
{
if (INTCON3bits.INT2IF)
{
INTCON3bits.INT2IF=0;
if (PORTBbits.RB2==0) flag=(flag+1)%2;//RB2 SET+/-
}//INT2

if (INTCONbits.INT0IF)
{
	INTCONbits.INT0IF = 0;
	if ((PORTAbits.RA4==1)&&(PORTCbits.RC0==0))// If B leads A?
			{
				direction[0]='L';	direction[1]='E'; 	direction[2]='F';	direction[3]='T';	direction[4]=' ';
				LATDbits.LATD5=1;LATDbits.LATD4=0;// direction status display
			}
	else {
		direction[0]='R';	direction[1]='I'; 	direction[2]='G';	direction[3]='H';	direction[4]='T';
		LATDbits.LATD5=0;LATDbits.LATD4=1;// direction status display
	  	 }
        
		if(stop_flag==0)// cancel or recover the reset?
		{
			TMR1H = 0xFF;      
        	TMR1L = 0x05; 
		}//INT0
	count++;// record Z pulses
	LATDbits.LATD6=1;// motor running
}

if  (PIR1bits.TMR1IF)
    {
        PIR1bits.TMR1IF = 0;          // clear (reset) flag
        LATDbits.LATD7 = 1;
        TMR1H = 0xFF;      // reset TMR1
		TMR1L=0x05;
  	}


if (INTCON3bits.INT1IF)//RB1 pressed, direction changed.
{	
	INTCON3bits.INT1IF=0;
	menu=4;
}


}//high interrupt

void interrupt low_priority ServiceLow(void)
{	
int Switch_Count=0;// switch debouncing
if (INTCONbits.TMR0IF)
	{
		INTCONbits.TMR0IF=0;
	TMR0H = 0;                   //65536
    TMR0L = 0;
	if (speed==0) {LATD=0;}	// motor is stopped
	speed=count*57+count/4;// caculate speed
	count=0;//reset count
	}


if ((menu==0)&&(INTCONbits.RBIF))// main menu;
    {	
		INTCONbits.RBIF=0;  
	if (PORTBbits.RB4 == 1)	// set on anlge
		{
			Switch_Count=0;
			do					// switch debouncing
		{ 
			if (PORTBbits.RB4 == 1)
				Switch_Count++;
			else
				break;
			Delay10TCYx(125); // delay 5ms.
		} while (Switch_Count < 5);
		while (PORTBbits.RB4 == 1);	
	   
		if (Switch_Count==5)	
		menu=1;// goto set on angle menu
		}

		if (PORTBbits.RB5 == 1)	// set off anlge
		{
			Switch_Count=0;
			do					// switch debouncing
			{
		    	if (PORTBbits.RB5 == 1)
				Switch_Count++;
				else
				break;
				Delay10TCYx(125); 
			} while (Switch_Count < 5);
		while (PORTBbits.RB5 == 1);	
		if (Switch_Count==5)	menu=2;//goto set ff angle menu
		}
	
  	if (PORTBbits.RB6 == 1)// set speed
		{
				Switch_Count=0;
					do						// switch debouncing
					{ 
					if (PORTBbits.RB6 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); // delay 1250 cycles or 5ms.
					} while (Switch_Count < 5);
			while (PORTBbits.RB6 == 1);	
		
			if (Switch_Count==5)	menu=3; // goto set speed
		}
	}//main menu
if (INTCONbits.RBIF)// child menu
{
if (menu==1)// set on_angle
    {	
		INTCONbits.RBIF = 0;   // clear (reset) flag	
			if (PORTBbits.RB4 == 1)
				{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB4 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); 
					} while (Switch_Count < 5);
					while (PORTBbits.RB4 == 1);	
				if (Switch_Count==5)
					{
					if (flag==0)on_angle=on_angle+1; else on_angle=on_angle-1; // on angle+/-1
					}
				}

			if (PORTBbits.RB5 == 1)
				{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB5 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); 
					} while (Switch_Count < 5);
						while (PORTBbits.RB5 == 1);	
				if (Switch_Count==5)
				{
					if (flag==0)on_angle=on_angle+10; else on_angle=on_angle-10;  // // on angle+/-10
				}
				}
			if (on_angle>90) on_angle=90;//restrict on angle value
			if (on_angle<0)  on_angle=0;//restrict  on angle value

			if (PORTBbits.RB7 == 1)// back to menu
				{
					Switch_Count=0;
					do
					{ // monitor switch input for 5 lows in a row to debounce if (Switch_Pin == 0)
					if (PORTBbits.RB7 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); // delay 1250 cycles or 5ms.
					} while (Switch_Count < 5);					
					while (PORTBbits.RB7 == 1);	
					if (Switch_Count==5) menu=0;
				}
		  	if (PORTBbits.RB6 == 1)// set off angle
		{
					Switch_Count=0;
					do
					{ // monitor switch input for 5 lows in a row to debounce if (Switch_Pin == 0)
					if (PORTBbits.RB6 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); // delay 1250 cycles or 5ms.
					} while (Switch_Count < 5);								
				while (PORTBbits.RB6 == 1);	
			if (Switch_Count==5) menu=2;// goto set off angle menu;
		}


	}//menu1
	if (menu==2)// set off angle
    {	
				INTCONbits.RBIF = 0;
				if (PORTBbits.RB4 == 1)
				{	Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB4 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); 
					} while (Switch_Count < 5);
					while (PORTBbits.RB4 == 1);	
					if(Switch_Count == 5)
					{
					if (flag==0)off_angle=off_angle+1; else off_angle=off_angle-1; //  set off_angle+/-1
					}
				}
		

			if (PORTBbits.RB5 == 1)
				{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB5 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); 
					} while (Switch_Count < 5);
				while (PORTBbits.RB5 == 1);	
					if(Switch_Count == 5)
					{
					if (flag==0)off_angle=off_angle+10; else off_angle=off_angle-10; // set 0ff_angle+/-10 
					} 
				}
			if (off_angle>90) off_angle=90;
			if (off_angle<0)  off_angle=0;
				  	if (PORTBbits.RB6 == 1)// set on_angle
		{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB6 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125);
					} while (Switch_Count < 5);								
				while (PORTBbits.RB6 == 1);	
			if (Switch_Count==5) menu=1;// go to set on  angle menu
		}


				if (PORTBbits.RB7 == 1)
				{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB7 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); 
					} while (Switch_Count < 5);					
					while (PORTBbits.RB7 == 1);	
					if (Switch_Count==5) menu=0;// go to main menu
				}

	}//menu2
	if (menu==3)// set speed
	{
			INTCONbits.RBIF = 0;
	if (PORTBbits.RB4 == 1)
				{
					Switch_Count=0;
					do
					{
					if (PORTBbits.RB4 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); 
					} while (Switch_Count < 5);

					while (PORTBbits.RB4 == 1);	
					if (Switch_Count==5)
					{
					if(flag==0)rotate_speed=rotate_speed+1; else rotate_speed=rotate_speed-1; // flag=0 speed+1 flag=1 speed-1
					}
				}
			
			
			if (PORTBbits.RB5 == 1)
				{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB5 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); // delay 1250 cycles or 5ms.
					} while (Switch_Count < 5);
						while (PORTBbits.RB5 == 1);	
					if (Switch_Count==5)
					{
					if (flag==0) rotate_speed=rotate_speed+10; else rotate_speed=rotate_speed-10;// speed+/-10
					}
				}
			if (PORTBbits.RB6 == 1)
				{
					Switch_Count=0;
					do
					{ 
					if (PORTBbits.RB6 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); // delay 250 cycles or 5ms.
					} while (Switch_Count < 5);
					while (PORTBbits.RB6 == 1);	
					if (Switch_Count==5)
					{
					if (flag==0)  rotate_speed=rotate_speed+100; else rotate_speed=rotate_speed-100;
					}
				}	
				
				if (rotate_speed<=1000) rotate_speed=1000;
				if (rotate_speed>=6000) rotate_speed=6000;
				
			if (PORTBbits.RB7 == 1)
				{
					Switch_Count=0;
					do
					{ // monitor switch input for 5 lows in a row to debounce if (Switch_Pin == 0)
					if (PORTBbits.RB7 == 1)
					Switch_Count++;
					else
						break;
						Delay10TCYx(125); // delay 1250 cycles or 5ms.
					} while (Switch_Count < 5);					
					while (PORTBbits.RB7 == 1);	
					if (Switch_Count==5) menu=0;// go back to main menu
				}
	}//menu3
}//Child menu 
}//low


// Intialise the system - 
void InitializeSystem(void)			
{
	ANSEL=0x00;
	OSCCON = 0b01110000;
	OSCTUNEbits.PLLEN = 0; 					// change to 1 to turn on the PLL CLK * 4

	// Setup I/O Ports.
    TRISA = 0b00001000; //PORTA IO SETTING				
	TRISB = 0b11111111;	//PORTB IO setting
	TRISC = 0b00000001;// PORTC IO setting
	TRISE = 0b00000111;// Set tristate on E (may be overridden in ADC_INIT)
	TRISD = 0b00001000;	// TRISD is LED input/output
	LATD = 0;		   // turn off LEDS
	IOCB=0xF0;			// IOCB register Enable RBIF
	oled_res = 1;							// do not reset LCD yet
	oled_cs = 1;							// do not select the LCD
	INTCON2bits.RBPU = 0;		// enable PORTB internal pullups
	WPUBbits.WPUB0 = 0;			// disable PORTB RB0 pull-up
	WPUBbits.WPUB1 = 1;			// Enable PORTB RB1
	WPUBbits.WPUB2 = 1;	
    WPUBbits.WPUB3 = 0;
	WPUBbits.WPUB4 = 0;	
	WPUBbits.WPUB5 = 0;	
    WPUBbits.WPUB6 = 0;
	WPUBbits.WPUB7 = 0;
	// Setup TMR1
	// Configure Timer 1
	T1CON = 0b00000011;                 // TIMER 1 ENABLED- EXETERNAL CLOCK ENABLED-no prescale - increments every instruction clock
    T1CONbits.T1CKPS0 = 0;               //PRESCALER 1:1
	T1CONbits.T1CKPS1 = 0;	
    // Set up Interrupts for timer
    INTCONbits.TMR0IF = 0;          // clear roll-over interrupt flag
    INTCON2bits.TMR0IP = 0;         // Timer0 is low priority interrupt
    INTCONbits.TMR0IE = 1;          // enable the Timer0 interrupt.
    // Set up timer itself
 	T0CON = 0b00000101;             // prescale 1:64 
    TMR0H = 0;                      // clear timer - always write upper byte first
    TMR0L = 0;
    T0CONbits.TMR0ON = 1;           // start timer
	// Configure MSSP for SPI master mode
	SSPCON1 = 0b00110001;					// clock idle high, Clk /64
	SSPSTAT = 0b00000000;
	TMR1H = 0xFF;                          // clear timer - always write upper byte first
	TMR1L = 0xFF-250;
	CCP1CON = 0b00000010;				// compare mode, toggle output on match
	CCP2CON = 0b00000010;				// compare mode, toggle output on match
	CCPR1H=0xFF;
	CCPR2H=0xFF;	
	CCPR1L = 0x13;  					//TURN ON ANGLE = 10 DEG
	CCPR2L = 0x66;						//TURN OFF ANGLE= 70 DEG
	T1CONbits.TMR1ON = 1;               // start timer 1
	RCONbits.IPEN = 1;                 // Enable priority levels on interrupts
	PIR1 = 0;
	PIE1bits.TMR1IE = 1;	// Enable TIMER1 Interrupt
	IPR1 = 0;
	IPR2 = 0;
	IPR1bits.TMR1IP = 1;	// high priority
	PIR2=0;
    INTCON2bits.INTEDG0 = 0;    // interrupt on falling edge of INT0 (switch pressed)
    INTCONbits.INT0IF = 0;      // ensure flag is cleared
    INTCONbits.INT0IE = 1;
	
	INTCON2bits.INTEDG1 = 0;    // interrupt on falling edge of INT1 (switch pressed)
    INTCON3bits.INT1IF = 0;      // ensure flag is cleared
    INTCON3bits.INT1IE = 1;     // Enable INT1 Interrupt
	INTCON3bits.INT1IP=1;       // high priority
	
	INTCON2bits.INTEDG2 = 0;    // interrupt on falling edge of INT2 (switch pressed)
    INTCON3bits.INT2IF = 0;      // ensure flag is cleared
    INTCON3bits.INT2IE = 1;		// Enable INT2 Interrupt
	INTCON3bits.INT2IP=1;       // high priority

	INTCONbits.RBIE=1;  // Enable RBIF Interrupt
	INTCONbits.RBIF=0;
	INTCON2bits.RBIP=0;// low priority
	INTCONbits.PEIE = 1; 
	INTCONbits.GIEH = 1;// Interrupting enabled.

} // end InitializeSystem
void ADC_Init(void)
{ // initialize the Analog-To-Digital converter.
	ANSEL = 0;	//turn off all other analog inputs
	ANSELH = 0;
 	ANSELbits.ANS5 = 1;	// turn on RE0 analog
    ADCON2 = 0b00111000;
   	ADCON0 = 0b00010101;

}
unsigned char ADC_Convert(void)
{ // start an ADC conversion and return the 8 most-significant bits of the result
    ADCON0bits.GO_DONE = 1;             // start conversion
    while (ADCON0bits.GO_DONE == 1);    // wait for it to complete
    return ADRESH;                      // return high byte of result
}

