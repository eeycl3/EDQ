#include <p18f46k20.h>
#include "oled_jib.h"
#include "oled_cmd.h"
#include "oled_interface.h"

void oled_puts_rom_1x(char *s)
{
	while(*s)
		oled_putc_1x(*s++);
}

void oled_puts_rom_2x(char *s)
{
	while(*s)
		oled_putc_2x(*s++);
}