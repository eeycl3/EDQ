
#include <p18f46K20.h>


#pragma config IESO=OFF, FCMEN=OFF, FOSC=INTIO67, PWRT=OFF, BOREN=OFF, WDTEN=OFF
#pragma config WDTPS=32768, MCLRE=ON, LPT1OSC=OFF, PBADEN=OFF, CCP2MX=PORTBE
#pragma config STVREN=OFF, LVP=OFF, XINST=OFF, DEBUG=OFF, CP0=OFF, CP1=OFF
#pragma config CP2=OFF, CP3=OFF, CPB=OFF, CPD=OFF, WRT0=OFF, WRT1=OFF
#pragma config WRT2=OFF, WRT3=OFF, WRTB=OFF, WRTC=OFF, WRTD=OFF, EBTR0=OFF
#pragma config EBTR1=OFF, EBTR2=OFF, EBTR3=OFF, EBTRB=OFF


// Various includes for the display driver - not that these are MODIFIED from the originals
#include <stdio.h>

#include "delays.h"
#include "oled_interface.h"
#include "oled_jib.h" 
#include "oled_cmd.h"

// This allows us to define strings which are held in ROM (of which we have considerable more than RAM). The text cannot be changed but where this is OK this is effieicent use of resourcses
rom const unsigned char hello[] = "Hello";
rom const unsigned char world[] = "World";
unsigned int delay;


/** D E C L A R A T I O N S **************************************************/

void InitializeSystem(void);


void main(void){

	char temp;
	unsigned int RandomNo;
	auto char buffer[20];	// A buffer into which we place text for sending to the OLED (do not worry about the 'auto' it is used to match the definition of sprintf in <stdio.h?
	unsigned int i;
	InitializeSystem();


	delay = 30000;
	while(delay--);


	// These are the functions you need to use to initialise the display
	oled_init();
	oled_clear();
	oled_refresh();


	// This is the demonstration code provided with the board that shows how
	// individual characters can be displayed.
	oled_putc_2x('\n');
	oled_putc_2x('\t');
	oled_putc_2x('\t');


	oled_putc_2x('H');
	oled_putc_2x('e');
	oled_putc_2x('l');
	oled_putc_2x('l');
	oled_putc_2x('o');


	oled_putc_2x('\n');
	oled_putc_2x('\t');
	oled_putc_2x('\t');
	oled_putc_2x('\t');

	oled_putc_2x('W');
	oled_putc_2x('o');
	oled_putc_2x('r');
	oled_putc_2x('l');
	oled_putc_2x('d');

	// And refresh the display so we can see things!	
	oled_refresh();

	Delay10KTCYx(250);	// Slight delay before moving to the next display example

	// If you wish to display a FIXED string we use the following (ie one where the string contents is held in ROM) we use

	// Clear the display
	oled_clear();

	// single height	
	oled_puts_rom_1x ("James - ROM");

	// Double height	
	oled_puts_rom_2x ("\nJames - ROM");

	// And refresh the display so we can see things!	
	oled_refresh();

	Delay10KTCYx(250);	// Slight delay before moving to the next display example

	// If the string is defined in the main() code, either within "" or as a character array defined in main we use
	// and as such in RAM we use

	// Clear the display
	oled_clear();
	
	sprintf (buffer, "James - RAM\0");		// sprints works like printf but the output is sent to a string (which is the 1st parameter)

	// single height	
	oled_puts_1x (buffer);

	// Double height	

	oled_puts_2x (buffer);

	// And refresh the display so we can see things!	
	oled_refresh();

	// OK - now for the 'die' display (we will use these as the possible shapes - you can even pick random shapes to display if you like!
	//
	// This uses an additional font table (see font.h) and allows you to specify the column to display the die	
	// Each die is draw across 2 lines (each 8 pixels high) with each line being 20 pixels wide. The maximum width
	// of the screen is 128 pixels so the last valid column that can be used is 118.
	//
	// It requires two parameters:
	//
	//			die_value 	(1->6) 
	//			col 		(0-128) 
	//
	//  eg.  oled_display_die (2, 75 )
	//
	// Note that the screen does not clear in this function (so allowing two die faces to be loaded and then displayed
	
	while ( 1)
	{
		for ( i = 1 ; i <= 6 ; i ++ )
		{
			// Now to what for a short time - clear the display and then display a die face!
			// and the 'opposite' die face

			Delay10KTCYx(250);	
	
			// Clear the display
			oled_clear();
	
			// Turn the display off (we can still write to it) - this is optional
			SetDisplayOnOff(OFF);

			// Display shape 1 in column 0 on row 2 where the number comes from the 'noise' on the ADC
			oled_WriteDie ( 1,0, 2);

			// Display a die 'i' in column 50 on row 1 
			oled_WriteDie ( i,50, 1);

			// And die '7-i' in column 100, row 2
			oled_WriteDie ( (7-i),100, 2);

			// Turn on the displa
			SetDisplayOnOff(ON);

			// And refresh the display so we can see things!	
			oled_refresh();
	
		}
	}

}



// Intialise the system - you should not need to change any code here 
void InitializeSystem(void)			
{

	OSCCON = 0b01110000;
	OSCTUNEbits.PLLEN = 0; 					// turn off the PLL

	// Setup I/O Ports.
	
	TRISA = 0;								// TRISA outputs
	LATA = 0b11110000;						// drive PORTA pins low

	oled_res = 1;							// do not reset LCD yet
	oled_cs = 1;							// do not select the LCD

	TRISB = 0b11001111;

	LATC = 0b00101000;						// Set up port C
	TRISC = 0b00000000;

	TRISD = 0;								// TRISD is LED output
	LATD = 0;								// turn off LEDS

	TRISE = 0b00000111;						// Set tristate on E (may be overridden in ADC_INIT)

	// Setup TMR1
	// Configure Timer 1
	T1CON 	= 0b00001111;
		
	// Setup TMR2
	T2CON = 0b00000100;						// 1:1 prescaler
	PR2 = 0xFF;
	T0CON = 0x80;

	// Configure MSSP for SPI master mode
	SSPCON1 = 0b00110010;					// clock idle high, Clk /64

	SSPSTAT = 0b00000000;

	PIR1bits.TMR1IF = 0; 
	PIE1bits.TMR1IE = 1; 

	INTCONbits.PEIE = 1; 
	INTCONbits.GIE = 0; 

} // end InitializeSystem



