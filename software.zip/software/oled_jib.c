#include <p18f46k20.h>
#include "oled_jib.h"
#include "oled_cmd.h"
#include "oled_interface.h"

#define ON 1
#define OFF 0
#define ALTERNATE 1
#define SEQUENTIAL 0



// VRAM needed for SPI interface because there is no way to read
// the data from the display.
// If a parallel interface is used, the vram can be eliminated
// and the plot functions changed to use the read/modify/write to
// the display ram.

unsigned char g_pucFont[95][5]={
    { 0x00, 0x00, 0x00, 0x00, 0x00 }, // " " 0x20
    { 0x00, 0x00, 0x4f, 0x00, 0x00 }, // !   0x21
    { 0x00, 0x07, 0x00, 0x07, 0x00 }, // "   0x22
    { 0x14, 0x7f, 0x14, 0x7f, 0x14 }, // #   0x23
    { 0x24, 0x2a, 0x7f, 0x2a, 0x12 }, // $   0x24
    { 0x23, 0x13, 0x08, 0x64, 0x62 }, // %   0x25
    { 0x36, 0x49, 0x55, 0x22, 0x50 }, // &   0x26
    { 0x00, 0x05, 0x03, 0x00, 0x00 }, // '   0x27
    { 0x00, 0x1c, 0x22, 0x41, 0x00 }, // (   0x28
    { 0x00, 0x41, 0x22, 0x1c, 0x00 }, // )   0x29
    { 0x14, 0x08, 0x3e, 0x08, 0x14 }, // *   0x2A
    { 0x08, 0x08, 0x3e, 0x08, 0x08 }, // +   0x2B
    { 0x00, 0x50, 0x30, 0x00, 0x00 }, // ,   0x2C
    { 0x08, 0x08, 0x08, 0x08, 0x08 }, // -   0x2D
    { 0x00, 0x60, 0x60, 0x00, 0x00 }, // .   0x2E
    { 0x20, 0x10, 0x08, 0x04, 0x02 }, // /   0x2F
    { 0x3e, 0x51, 0x49, 0x45, 0x3e }, // 0   0x30
    { 0x00, 0x42, 0x7f, 0x40, 0x00 }, // 1   0x31
    { 0x42, 0x61, 0x51, 0x49, 0x46 }, // 2   0x32
    { 0x21, 0x41, 0x45, 0x4b, 0x31 }, // 3   0x33
    { 0x18, 0x14, 0x12, 0x7f, 0x10 }, // 4   0x34
    { 0x27, 0x45, 0x45, 0x45, 0x39 }, // 5   0x35
    { 0x3c, 0x4a, 0x49, 0x49, 0x30 }, // 6   0x36
    { 0x01, 0x71, 0x09, 0x05, 0x03 }, // 7   0x37
    { 0x36, 0x49, 0x49, 0x49, 0x36 }, // 8   0x38
    { 0x06, 0x49, 0x49, 0x29, 0x1e }, // 9   0x39
    { 0x00, 0x36, 0x36, 0x00, 0x00 }, // :   0x3A
    { 0x00, 0x56, 0x36, 0x00, 0x00 }, // ;   0x3B
    { 0x08, 0x14, 0x22, 0x41, 0x00 }, // <   0x3C
    { 0x14, 0x14, 0x14, 0x14, 0x14 }, // =   0x3D
    { 0x00, 0x41, 0x22, 0x14, 0x08 }, // >   0x3E
    { 0x02, 0x01, 0x51, 0x09, 0x06 }, // ?   0x3F
    { 0x32, 0x49, 0x79, 0x41, 0x3e }, // @   0x40
    { 0x7e, 0x11, 0x11, 0x11, 0x7e }, // A   0x41
    { 0x7f, 0x49, 0x49, 0x49, 0x36 }, // B   0x42
    { 0x3e, 0x41, 0x41, 0x41, 0x22 }, // C   0x43
    { 0x7f, 0x41, 0x41, 0x22, 0x1c }, // D   0x44
    { 0x7f, 0x49, 0x49, 0x49, 0x41 }, // E   0x45
    { 0x7f, 0x09, 0x09, 0x09, 0x01 }, // F   0x46
    { 0x3e, 0x41, 0x49, 0x49, 0x7a }, // G   0x47
    { 0x7f, 0x08, 0x08, 0x08, 0x7f }, // H   0x48
    { 0x00, 0x41, 0x7f, 0x41, 0x00 }, // I   0x49
    { 0x20, 0x40, 0x41, 0x3f, 0x01 }, // J   0x4A
    { 0x7f, 0x08, 0x14, 0x22, 0x41 }, // K   0x4B
    { 0x7f, 0x40, 0x40, 0x40, 0x40 }, // L   0x4C
    { 0x7f, 0x02, 0x0c, 0x02, 0x7f }, // M   0x4D
    { 0x7f, 0x04, 0x08, 0x10, 0x7f }, // N   0x4E
    { 0x3e, 0x41, 0x41, 0x41, 0x3e }, // O   0x4F
    { 0x7f, 0x09, 0x09, 0x09, 0x06 }, // P   0X50
    { 0x3e, 0x41, 0x51, 0x21, 0x5e }, // Q   0X51
    { 0x7f, 0x09, 0x19, 0x29, 0x46 }, // R   0X52
    { 0x46, 0x49, 0x49, 0x49, 0x31 }, // S   0X53
    { 0x01, 0x01, 0x7f, 0x01, 0x01 }, // T   0X54
    { 0x3f, 0x40, 0x40, 0x40, 0x3f }, // U   0X55
    { 0x1f, 0x20, 0x40, 0x20, 0x1f }, // V   0X56
    { 0x3f, 0x40, 0x38, 0x40, 0x3f }, // W   0X57
    { 0x63, 0x14, 0x08, 0x14, 0x63 }, // X   0X58
    { 0x07, 0x08, 0x70, 0x08, 0x07 }, // Y   0X59
    { 0x61, 0x51, 0x49, 0x45, 0x43 }, // Z   0X5A
    { 0x00, 0x7f, 0x41, 0x41, 0x00 }, // [   0X5B
    { 0x02, 0x04, 0x08, 0x10, 0x20 }, // "\" 0X5C
    { 0x00, 0x41, 0x41, 0x7f, 0x00 }, // ]   0X5D
    { 0x04, 0x02, 0x01, 0x02, 0x04 }, // ^   0X5E
    { 0x40, 0x40, 0x40, 0x40, 0x40 }, // _   0X5F
    { 0x00, 0x01, 0x02, 0x04, 0x00 }, // `   0X60
    { 0x20, 0x54, 0x54, 0x54, 0x78 }, // a   0X61
    { 0x7f, 0x48, 0x44, 0x44, 0x38 }, // b   0X62
    { 0x38, 0x44, 0x44, 0x44, 0x20 }, // c   0X63
    { 0x38, 0x44, 0x44, 0x48, 0x7f }, // d   0X64
    { 0x38, 0x54, 0x54, 0x54, 0x18 }, // e   0X65
    { 0x08, 0x7e, 0x09, 0x01, 0x02 }, // f   0X66
    { 0x0c, 0x52, 0x52, 0x52, 0x3e }, // g   0X67
    { 0x7f, 0x08, 0x04, 0x04, 0x78 }, // h   0X68
    { 0x00, 0x44, 0x7d, 0x40, 0x00 }, // i   0X69
    { 0x20, 0x40, 0x44, 0x3d, 0x00 }, // j   0X6A
    { 0x7f, 0x10, 0x28, 0x44, 0x00 }, // k   0X6B
    { 0x00, 0x41, 0x7f, 0x40, 0x00 }, // l   0X6C
    { 0x7c, 0x04, 0x18, 0x04, 0x78 }, // m   0X6D
    { 0x7c, 0x08, 0x04, 0x04, 0x78 }, // n   0X6E
    { 0x38, 0x44, 0x44, 0x44, 0x38 }, // o   0X6F
    { 0x7c, 0x14, 0x14, 0x14, 0x08 }, // p   0X70
    { 0x08, 0x14, 0x14, 0x18, 0x7c }, // q   0X71
    { 0x7c, 0x08, 0x04, 0x04, 0x08 }, // r   0X72
    { 0x48, 0x54, 0x54, 0x54, 0x20 }, // s   0X73
    { 0x04, 0x3f, 0x44, 0x40, 0x20 }, // t   0X74
    { 0x3c, 0x40, 0x40, 0x20, 0x7c }, // u   0X75
    { 0x1c, 0x20, 0x40, 0x20, 0x1c }, // v   0X76
    { 0x3c, 0x40, 0x30, 0x40, 0x3c }, // w   0X77
    { 0x44, 0x28, 0x10, 0x28, 0x44 }, // x   0X78
    { 0x0c, 0x50, 0x50, 0x50, 0x3c }, // y   0X79
    { 0x44, 0x64, 0x54, 0x4c, 0x44 }, // z   0X7A
    { 0x00, 0x08, 0x36, 0x41, 0x00 }, // {   0X7B
    { 0x00, 0x00, 0x7f, 0x00, 0x00 }, // |   0X7C
    { 0x00, 0x41, 0x36, 0x08, 0x00 }, // }   0X7D
    { 0x02, 0x01, 0x02, 0x04, 0x02 }, // ~   0X7E
};


//#pragma OLEDDATA_0
unsigned char vram_0[128];

//#pragma OLEDDATA_1
unsigned char vram_1[128];

//#pragma OLEDDATA_2
unsigned char vram_2[128];

//#pragma OLEDDATA_3
unsigned char vram_3[128];

//#pragma OLEDDATA_4
unsigned char vram_4[128];

//#pragma OLEDDATA_5
unsigned char vram_5[128];

//#pragma OLEDDATA_6
unsigned char vram_6[128];

//pragma OLEDDATA_7
unsigned char vram_7[128];

unsigned char *vram[8] = {vram_0, vram_1, vram_2, vram_3,
	                      vram_4, vram_5, vram_6, vram_7};

unsigned char c_row_1x; // current row counter for 8pixel high font.  values 0-7 are allowed
unsigned char c_col_1x; // current column counter for 5 pixel wide font. Values 0-15 are allowed

unsigned char c_row_2x; // current row counter for 16 pixel high font.  Values 0-3 are allowed
unsigned char c_col_2x; // current column counter for 5 pixel wide font.  Values 0-15 are allowed

unsigned char Convert1xto2x(unsigned char uplow, unsigned char byte);
char is_printable(char c);

void oled_init(void)
{	
	int temp;
	oled_cs = 1;
	oled_res = 0;
	oled_reset();
	SetDisplayOnOff(OFF);			// send display off command
	oled_clear();					// clear oled ram
	oled_refresh();					// send data to clear screen

	//DCDCOnOff(ON);					// sendCommand(0xAD);  //Original PIC display
    ChargePumpOn();								// sendCommand(0x8B); //SSD106

	SetSegmentReMap(1);				// sendCommand(0xA1);

	SetCOMHWConfig(ALTERNATE);		// sendCommand(0xDA);
									// sendCommand(0x12);
	
	SetCOMScan(1);					// sendCommand(0xC8);

	SetMultiplexRatio(0x3F);		// sendCommand(0xA8);
									// sendCommand(0x3F);

	SetVCOMDeselectLevel(0x23);		// sendCommand(0xDB);
									// sendCommand(0x23);

	SetPrechargePeriod(0x22);		// sendCommand(0xD9);
									// sendCommand(0x22);


	SetDisplayClockDivider(0xA0);	// sendCommand(0xD5);
									// sendCommand(0xA0);

	SetDisplayOffset(0);			// sendCommand(0xD3);
									// sendCommand(0x00);

	SetDisplayStartLine(0);			// sendCommand(0x40)


	SetContrastControlRegister(0x5c);// sendCommand(0x81)
									// sendCommand(0x60);


	SetDisplayOnOff(ON);
	SetInverse(OFF);				// sendCommand(0xA6);

	SetLowerColumnAddress(2);		// sendCommand(0x02)
	SetHigherColumnAddress(0);		// sendCommand(0x10)
	EntireDisplayOnOff(OFF);			// sendCommand(0xA4);
	SetBrightness(0x80);


}

void oled_clear()
{
	unsigned char x,y;
	unsigned char *p;
	for(y = 0 ; y < 8 ; y ++)
	{
		p = vram[y];
		for(x = 0; x < 128; x ++)
		{
			p[x] = 0;
		}
	}
	c_row_1x = 0;
	c_col_1x = 0;
	c_row_2x = 0;
	c_col_2x = 0;
}

void oled_draw_row(char r, unsigned char *d)
// d is a pointer to 128 bytes
// r is the row number
{
	char c;
	SetPageAddress(r);
	SetLowerColumnAddress(2);  //0 for ssd1305 2 for ssd1306
	SetHigherColumnAddress(0);
	oled_SendData(d,128);
}

void oled_scroll_left()
{
}

void oled_refresh()
// copy the data from the VRAM buffer in the micro to the display 1 row at a time
{
	unsigned char z;
		
	for( z = 0; z < 8; z ++)
	{
		oled_draw_row(z,vram[z]);
	}
}

void oled_scroll_right()
{
}

void oled_SetBrightness(char b)
{
	SetBrightness(b);
}

void oled_off()
{
	SetDisplayOnOff(OFF);
}

void oled_on()
{
	SetDisplayOnOff(ON);
}

void oled_reset()
{
	int temp;
	temp = 35530;
	while(temp--);
	
	oled_res = 0;
	temp = 35530;
	while(temp--);
	oled_res = 1;
	
}

void putpixel_vram(unsigned char x,unsigned char y,unsigned char color)
{
	unsigned char *p;
	char m = 0x01 << (y%8);

	p = &vram[y/8][x];

	if(color)
		*p |=  m;
	else
		*p &= ~m;
}

char getpixel_vram(unsigned char x, unsigned char y)
{
	
	return (vram[y/8][x]) & (0x01 << (y%8));
}

char is_printable(char c)
{
	return( (0x20 <= c) && (c <= 0x7E));
}

void oled_puts_1x(char *s)
{
	while(*s)
		oled_putc_1x(*s++);
}

void oled_puts_2x(char *s)
{
	while(*s)
		oled_putc_2x(*s++);
}

void oled_putc_1x(char c)
{
		if(is_printable(c)) // all printable characters
		{
			if(c_col_1x < 128)
			{
				oled_WriteChar1x(c,c_row_1x,c_col_1x);
				c_col_1x += 6;
			}
		}
		else if( c == '\n' || c == '\r') // carraige return or line feed
		{
			for( ; c_col_1x < 128; c_col_1x++)
				vram[c_row_1x][c_col_1x] = 0x00; // destroy the line
			c_row_1x +=1;
			c_col_1x = 0;
		}
		else if(c == '\t') // tab
		{
		if(c_col_1x < 128)
			{
				oled_WriteChar1x(c,c_row_1x,c_col_1x);
				c_col_1x += 6;
			}
		if(c_col_1x < 128)
			{
				oled_WriteChar1x(c,c_row_1x,c_col_1x);
				c_col_1x += 6;
			}
		if(c_col_1x < 128)
			{
				oled_WriteChar1x(c,c_row_1x,c_col_1x);
				c_col_1x += 6;
			}
		//	oled_putc_1x(' ');
		//	oled_putc_1x(' ');
		//	oled_putc_1x(' ');
		}
		if( c_row_1x >= 8)
			c_row_1x = 0;
}

void oled_putc_2x(char c)
{
		if(is_printable(c)) // all printable characters
		{
			if(c_col_1x < 128 && c_row_1x < 7)
			{
				oled_WriteChar2x(c,c_row_1x,c_col_1x);
				c_col_1x += 6;
			}
		}
		else if( c == '\n' || c == '\r') // carraige return or line feed
		{
			for( ; c_col_1x < 128; c_col_1x++)
				vram[c_row_1x][c_col_1x] = 0x00; // destroy the line
			c_row_1x +=2;
			c_col_1x = 0;
		}
		else if(c == '\t') // tab
		{
			oled_putc_1x(' ');
			oled_putc_1x(' ');
			oled_putc_1x(' ');
		}
		if( c_row_1x == 8)
			c_row_1x = 0;
}

void oled_WriteChar1x(char letter, unsigned char page, unsigned char column)
{
	unsigned char *p,x;
	letter -= ' ';					// Adjust character to table that starts at 0x20

	p = &vram[page][column];
	
	for( x = 0; x + column < 128 && x < 5 ; x ++)
	{
		*p ++ = g_pucFont[letter][x];
	}
	*p= 0;
}

void oled_WriteChar2x(char letter, unsigned char page, unsigned char column)
{
	unsigned char *p1,*p2,x;
	letter -= ' ';					// Adjust character to table that starts at 0x20

	p1 = &vram[page][column];
	p2 = &vram[page+1][column];
	
	for( x = 0; x + column < 128 && x < 5 ; x ++)
	{
		*p1 ++ = Convert1xto2x(0,g_pucFont[letter][x]);
		*p2 ++ = Convert1xto2x(1,g_pucFont[letter][x]);
	}
	*p1 = 0;
	*p2 = 0;
}

unsigned char Convert1xto2x(unsigned char uplow, unsigned char byte)
{
	unsigned char result;

	result = 0;
	if(uplow)
	{
		if(byte&0x10)
		{
			result |= 0x01;
			result |= 0x02;
		}
		if(byte&0x20)
		{
			result |= 0x04;
			result |= 0x08;
		}
		if(byte&0x40)
		{
			result |= 0x10;
			result |= 0x20;
		}
		if(byte&0x80)
		{
			result |= 0x40;
			result |= 0x80;
		}
	}
	else
	{
		if(byte&0x01)
		{
			result |= 0x01;
			result |= 0x02;
		}
		if(byte&0x02)
		{
			result |= 0x04;
			result |= 0x08;
		}
		if(byte&0x04)
		{
			result |= 0x10;
			result |= 0x20;
		}
		if(byte&0x08)
		{
			result |= 0x40;
			result |= 0x80;
		}
	}
	return result;
}

void oled_ScreenSaver(unsigned char enable)
{
	if(enable == 1)
	{
		SetupHorizontalScroll(0x01,0x00,0x00,0x07);
		ActivateHorizontalScroll();
	}
	else
		DeactivateHorizontalScroll();
	return;
}

void oled_plotbar(unsigned char r, unsigned char c, unsigned char v)
{
	vram[r][c] = v;
}


